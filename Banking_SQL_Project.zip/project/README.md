# Banking Customer & Transaction Analysis Using SQL

Analyze customer behavior, transaction trends, account activity, and regional
branch performance for a retail bank using advanced SQL — JOINs, CTEs, window
functions, aggregations, CASE statements, and date functions — to generate
insights that support customer segmentation and strategic decision-making.

## 1. Project Overview

This project builds and analyzes a relational banking database covering
**10,000 customers**, **10,000 transaction/account records**, and **1,000
branches** across 6 cities and 4 regions in India, all served by a single
bank entity (HDFC Bank in this dataset). The goal is to turn raw
customer, transaction, and branch data into business-ready insights, the
same way an analytics/BI team would support a retail banking division.

**Tech stack:** SQL (SQLite for local execution; portable to
MySQL/PostgreSQL with minor syntax tweaks), Python (`pandas` /
`sqlite3` used only to build the DB from CSVs).

## 2. Dataset

| File | Rows | Description |
|---|---|---|
| `data/customer_data.csv` | 10,000 | Customer profile: age, type (Employee/Business/Individual), city, region, home branch |
| `data/transaction_data.csv` | 10,000 | Per-transaction record: account type, balance, transaction amount, investment amount/type, date |
| `data/bank_data.csv` | 1,000 | Branch-level financials: city, region, revenue, expenses, profit margin |

## 3. Entity-Relationship Design

```
 Branches (1) ───< Customers (many) ───< Transactions (many)
 Branch_ID PK          Customer_ID PK        Transaction_ID PK
 City                  Branch_ID  FK ┘        Customer_ID FK ┘
 Region
 Firm_Revenue
 Expenses
 Profit_Margin
```

* One **Branch** serves many **Customers**.
* One **Customer** can have many **Transaction** records (multiple
  account snapshots / investment activity over time).

Schema DDL: [`sql/01_schema.sql`](sql/01_schema.sql)

## 4. What's in this repo

```
project/
├── data/                      # raw CSVs + built SQLite database
│   ├── bank_data.csv
│   ├── customer_data.csv
│   ├── transaction_data.csv
│   └── banking.db             # ready-to-query SQLite DB (pre-loaded)
├── sql/
│   ├──01_schema.sql           # DDL: table creation + indexes
│   └── 02_analysis_queries.sql# 16 analytical queries (see below)
├── docs/
│   └── insights.md            # write-up of key findings (verified against the DB)
└── README.md
```

## 5. How to run it

**Option A — SQLite (fastest, zero setup):**
```bash
sqlite3 data/banking.db < sql/01_schema.sql      # only needed if rebuilding
sqlite3 data/banking.db
sqlite> .read sql/02_analysis_queries.sql
```

**Option B — MySQL / PostgreSQL:**
Import the three CSVs into tables using the DDL in `01_schema.sql`
(swap `AUTOINCREMENT`/`TEXT` types as needed for your engine), then run
the queries in `02_analysis_queries.sql` as-is — they use standard
`JOIN`, `GROUP BY`, `CASE`, window functions (`RANK`, `LAG`, `SUM() OVER`),
and CTEs (`WITH`) that are ANSI-SQL compatible.

## 6. Analytical queries included (16 total)

| # | Query | SQL Techniques Used |
|---|---|---|
| 1 | Customer 360 view | Multi-table JOIN |
| 2 | Total balance & transaction volume by city | JOIN, GROUP BY, Aggregation |
| 3 | Customer segmentation by age group | CASE |
| 4 | High-value customer flagging | CASE, Aggregation |
| 5 | Dormant / low-engagement account detection | CTE, Date functions |
| 6 | Monthly transaction trend | Date functions, Aggregation |
| 7 | Year-over-year transaction growth | CTE, Window function (`LAG`) |
| 8 | Top 3 customers by balance per city | CTE, Window function (`RANK`) |
| 9 | Running total of deposits over time | Window function (`SUM() OVER`) |
| 10 | Account type distribution | Aggregation, Subquery |
| 11 | Investment preference by customer type | JOIN, Aggregation, CASE |
| 12 | Branch profitability ranking | Window function (`RANK`), CASE |
| 13 | Top 5 cities by total balance | Aggregation |
| 14 | Customer retention cohort analysis | CTE, Date functions |
| 15 | Below-average balance customers by account type | Subquery, Window function |
| 16 | Regional performance summary | Multi-JOIN, Aggregation, CASE |

Full query text: [`sql/02_analysis_queries.sql`](sql/02_analysis_queries.sql)

## 7. Key Insights (see [`docs/insights.md`](docs/insights.md) for full detail)

- **Kolhapur leads all cities** in total customer balance (₹9.07 Cr),
  narrowly ahead of Mumbai (₹8.83 Cr) and Nashik (₹8.60 Cr).
- Account types are **almost evenly split**: Current (33.6%), Savings
  (33.5%), Business (32.9%) — no single product dominates.
- The **36–50 age band is the largest customer segment** (2,322
  customers), followed closely by 51–65 and 65+ — skewing older than a
  typical digital-first bank.
- Transaction value **grew 27.7% in 2023 vs 2022**, then growth slowed to
  6.4% in 2024 (2025 figures are partial-year, data ends March 2025).
- Branch profit margins vary widely: several branches post **>99% profit
  margin** while the **regional averages sit at 22–26%**, flagging a small
  number of outlier branches worth investigating.
- **1,619 customers (25.6%)** qualify as **"High Value"** with combined
  balances ≥ ₹1,00,000; the top customer holds a combined balance of
  ₹4.10 lakh.
- **3,412 customers** had no transaction activity in the 12 months before
  the most recent date in the dataset — flagged as **dormant/at-risk**
  and a strong candidate list for re-engagement campaigns.

## 8. Outcomes

- Built and analyzed a relational banking database using advanced SQL
  concepts: JOINs, CTEs, window functions, aggregations, CASE statements,
  and date functions.
- Identified high-value customers, dormant accounts, transaction trends,
  and city-wise performance through 16 analytical SQL queries.
- Delivered actionable insights to support customer retention, targeted
  marketing, product optimization, and regional business growth in a
  banking environment.

## 9. Data limitations (good to mention in an interview)

- Each customer averages ~1.5 transaction records rather than a long
  transactional history, so cohort/retention numbers reflect **data
  availability more than true customer churn** — worth flagging if asked.
- `Age`, `Customer_Type`, and `City` contain ~500 missing values in
  `customer_data.csv`; `Firm_Revenue` has 50 missing values in
  `bank_data.csv`. Queries either filter these out explicitly or bucket
  them as `'Unknown'`.
